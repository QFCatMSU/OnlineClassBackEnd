#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  vector<Type> y(4);
  y(5);                  // 5 is not a valid index value here

  return 0;
}
