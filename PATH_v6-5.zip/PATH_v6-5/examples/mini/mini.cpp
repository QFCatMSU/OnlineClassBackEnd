#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  vector<Type> y(4);
  y(5);                  // 5 is not a valid index value here
  
  DATA_VECTOR(x);
  PARAMETER(mu);
  PARAMETER(logSigma);

  Type f = 0;
  f -= dnorm(x, mu, exp(logSigma), true).sum();

  return f;
}
