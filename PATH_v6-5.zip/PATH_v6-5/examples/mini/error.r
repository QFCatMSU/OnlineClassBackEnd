library(TMB)
# gdbsource("error.R",interactive = TRUE);

## Compile and load the model
#compile("error.cpp")
compile("error.cpp","-O1 -g",DLLFLAGS="")
dyn.load(dynlib("error"))

## Data and parameters
data <- list(x=rivers)
parameters <- list(mu=0, logSigma=0)

## Make a function object
obj <- MakeADFun(data, parameters, DLL="error")

## Call function minimizer
fit <- nlminb(obj$par, obj$fn, obj$gr)

## Get parameter uncertainties and convergence diagnostics
sdr <- sdreport(obj)
sdr
